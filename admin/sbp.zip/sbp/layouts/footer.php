<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Kelompok</b> 01 poliSurvey
    </div>
    <strong>Copyright &copy; 2024 <a href="https://www.polinema.ac.id/">Polinema</a>.</strong> All rights reserved.
  </footer>